"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toCalculationResponse = toCalculationResponse;
function toCalculationResponse(calculation) {
    return {
        id: calculation.id,
        number_of_pax: calculation.number_of_pax,
        transportation_id: calculation.transportation_id,
        flight_id: calculation.flight_id,
        travel_duration: calculation.travel_duration,
        mekkah_duration: calculation.mekkah_duration,
        maddinah_duration: calculation.maddinah_duration,
        hotel_mekkah_id: calculation.hotel_mekkah_id,
        hotel_maddinah_id: calculation.hotel_maddinah_id,
        muthawwif_id: calculation.muthawwif_id,
        handling_id: calculation.handling_id,
        total_price: calculation.total_price,
    };
}
