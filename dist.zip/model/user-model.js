"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toUserResponse = toUserResponse;
function toUserResponse(user) {
    return {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
        whatsapp_number: user.whatsapp_number,
        role: user.role,
    };
}
