"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculationValidation = void 0;
const zod_1 = require("zod");
class CalculationValidation {
}
exports.CalculationValidation = CalculationValidation;
CalculationValidation.CREATE = zod_1.z.object({
    number_of_pax: zod_1.z.number().int().positive('Jumlah pax harus positif').max(100, 'Jumlah pax maksimal 100'),
    transportation_id: zod_1.z.string(),
    flight_id: zod_1.z.string(),
    travel_duration: zod_1.z
        .number()
        .int()
        .positive('Durasi perjalanan harus positif')
        .max(100, 'Durasi perjalanan maksimal 100'),
    mekkah_duration: zod_1.z
        .number()
        .int()
        .positive('Durasi di Mekkah harus positif')
        .max(100, 'Durasi di Mekkah maksimal 100'),
    maddinah_duration: zod_1.z
        .number()
        .int()
        .positive('Durasi di Maddinah harus positif')
        .max(100, 'Durasi di Maddinah maksimal 100'),
    hotel_mekkah_id: zod_1.z.string(),
    hotel_maddinah_id: zod_1.z.string(),
    muthawwif_id: zod_1.z.string(),
    handling_id: zod_1.z.string(),
});
