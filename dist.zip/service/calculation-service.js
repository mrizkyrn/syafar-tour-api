"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculationService = void 0;
const database_1 = require("../application/database");
const logger_1 = require("../application/logger");
const response_error_1 = require("../error/response-error");
const calculation_model_1 = require("../model/calculation-model");
const calculation_validation_1 = require("../validation/calculation-validation");
const validation_1 = require("../validation/validation");
class CalculationService {
    static create(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const createRequest = validation_1.Validation.validate(calculation_validation_1.CalculationValidation.CREATE, request);
            const total_price = yield this.calculateTotal(createRequest);
            const calculation = yield database_1.prismaClient.calculation.create({
                data: Object.assign(Object.assign({}, createRequest), { total_price }),
            });
            logger_1.logger.debug('record created', calculation);
            return (0, calculation_model_1.toCalculationResponse)(calculation);
        });
    }
    static get(id) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(id);
            const calculation = yield database_1.prismaClient.calculation.findUnique({
                where: { id },
                include: {
                    transportation: {
                        select: {
                            name: true,
                        },
                    },
                    flight: {
                        select: {
                            name: true,
                        },
                    },
                    hotelMekkah: {
                        select: {
                            name: true,
                        },
                    },
                    hotelMaddinah: {
                        select: {
                            name: true,
                        },
                    },
                    muthawwif: {
                        select: {
                            name: true,
                        },
                    },
                    handling: {
                        select: {
                            name: true,
                        },
                    },
                },
            });
            console.log(calculation);
            if (!calculation) {
                throw new response_error_1.ResponseError(404, 'Calculation not found');
            }
            return calculation;
        });
    }
    static calculateTotal(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const { flight_id, hotel_mekkah_id, hotel_maddinah_id, transportation_id, muthawwif_id, handling_id, kotaMekkah, kotaMaddinah, } = request;
            const flightPrice = flight_id ? yield database_1.prismaClient.flight.findUnique({ where: { id: flight_id } }) : null;
            const hotelMekkahPrice = hotel_mekkah_id
                ? yield database_1.prismaClient.hotelMekkah.findUnique({ where: { id: hotel_mekkah_id } })
                : null;
            const hotelMaddinahPrice = hotel_maddinah_id
                ? yield database_1.prismaClient.hotelMaddinah.findUnique({ where: { id: hotel_maddinah_id } })
                : null;
            const transportationPrice = transportation_id
                ? yield database_1.prismaClient.transportation.findUnique({ where: { id: transportation_id } })
                : null;
            const muthawwifPrice = muthawwif_id
                ? yield database_1.prismaClient.muthawwif.findUnique({ where: { id: muthawwif_id } })
                : null;
            const handlingPrice = handling_id ? yield database_1.prismaClient.handling.findUnique({ where: { id: handling_id } }) : null;
            let totalPrice = 0;
            totalPrice += flightPrice ? flightPrice.price : 0;
            totalPrice += hotelMekkahPrice ? hotelMekkahPrice.price : 0;
            totalPrice += hotelMaddinahPrice ? hotelMaddinahPrice.price : 0;
            totalPrice += transportationPrice ? transportationPrice.price : 0;
            totalPrice += muthawwifPrice ? muthawwifPrice.price : 0;
            totalPrice += handlingPrice ? handlingPrice.price : 0;
            totalPrice += parseInt(kotaMekkah || '0') * (hotelMekkahPrice ? hotelMekkahPrice.price : 0);
            totalPrice += parseInt(kotaMaddinah || '0') * (hotelMaddinahPrice ? hotelMaddinahPrice.price : 0);
            return totalPrice;
        });
    }
}
exports.CalculationService = CalculationService;
