"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = require("../application/database");
const response_error_1 = require("../error/response-error");
const user_model_1 = require("../model/user-model");
const validation_1 = require("../validation/validation");
const auth_validation_1 = require("../validation/auth-validation");
class AuthService {
    static register(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const registerRequest = validation_1.Validation.validate(auth_validation_1.AuthValidation.REGISTER, request);
            const emailExists = yield database_1.prismaClient.user.findFirst({
                where: { email: registerRequest.email },
            });
            if (emailExists) {
                throw new response_error_1.ResponseError(400, 'Email already exists');
            }
            registerRequest.password = yield bcrypt_1.default.hash(registerRequest.password, 10);
            const user = yield database_1.prismaClient.user.create({
                data: registerRequest,
            });
            return (0, user_model_1.toUserResponse)(user);
        });
    }
    static login(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const loginRequest = validation_1.Validation.validate(auth_validation_1.AuthValidation.LOGIN, request);
            const user = yield database_1.prismaClient.user.findUnique({
                where: { email: loginRequest.email },
            });
            if (!user) {
                throw new response_error_1.ResponseError(400, 'Invalid username or password');
            }
            const passwordMatch = yield bcrypt_1.default.compare(loginRequest.password, user.password);
            if (!passwordMatch) {
                throw new response_error_1.ResponseError(400, 'Invalid username or password');
            }
            const token = jsonwebtoken_1.default.sign({
                id: user.id,
                email: user.email,
                full_name: user.full_name,
                role: user.role,
            }, String(process.env.JWT_SECRET), {
                expiresIn: 60 * 60 * 24, // 24 hours
            });
            const response = (0, user_model_1.toUserResponse)(user);
            response.token = token;
            return response;
        });
    }
}
exports.AuthService = AuthService;
