"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceService = void 0;
const database_1 = require("../application/database");
const response_error_1 = require("../error/response-error");
class PriceService {
    static getAll(name) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (name) {
                case 'flight':
                    return database_1.prismaClient.flight.findMany();
                case 'hotel-mekkah':
                    return database_1.prismaClient.hotelMekkah.findMany();
                case 'hotel-maddinah':
                    return database_1.prismaClient.hotelMaddinah.findMany();
                case 'transportation':
                    return database_1.prismaClient.transportation.findMany();
                case 'muthawwif':
                    return database_1.prismaClient.muthawwif.findMany();
                case 'handling':
                    return database_1.prismaClient.handling.findMany();
                default:
                    throw new response_error_1.ResponseError(400, 'Invalid name');
            }
        });
    }
    static bulkUpdate(name, request) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(request, name);
            switch (name) {
                case 'flight':
                    for (const flight of request) {
                        yield database_1.prismaClient.flight.update({
                            where: { id: flight.id },
                            data: {
                                name: flight.name,
                                price: flight.price,
                            },
                        });
                    }
                    break;
                case 'hotel-mekkah':
                    for (const hotelMekkah of request) {
                        yield database_1.prismaClient.hotelMekkah.update({
                            where: { id: hotelMekkah.id },
                            data: {
                                name: hotelMekkah.name,
                                price: hotelMekkah.price,
                            },
                        });
                    }
                    break;
                case 'hotel-maddinah':
                    for (const hotelMaddinah of request) {
                        yield database_1.prismaClient.hotelMaddinah.update({
                            where: { id: hotelMaddinah.id },
                            data: {
                                name: hotelMaddinah.name,
                                price: hotelMaddinah.price,
                            },
                        });
                    }
                    break;
                case 'transportation':
                    for (const transportation of request) {
                        yield database_1.prismaClient.transportation.update({
                            where: { id: transportation.id },
                            data: {
                                name: transportation.name,
                                price: transportation.price,
                            },
                        });
                    }
                    break;
                case 'muthawwif':
                    console.log('HERE');
                    for (const muthawwif of request) {
                        yield database_1.prismaClient.muthawwif.update({
                            where: { id: muthawwif.id },
                            data: {
                                name: muthawwif.name,
                                price: muthawwif.price,
                            },
                        });
                    }
                    break;
                case 'handling':
                    for (const handling of request) {
                        yield database_1.prismaClient.handling.update({
                            where: { id: handling.id },
                            data: {
                                name: handling.name,
                                price: handling.price,
                            },
                        });
                    }
                    break;
                default:
                    throw new response_error_1.ResponseError(400, 'Invalid name');
            }
            return true;
        });
    }
}
exports.PriceService = PriceService;
