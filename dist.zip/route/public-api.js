"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicRouter = void 0;
const express_1 = __importDefault(require("express"));
const auth_controller_1 = require("../controller/auth-controller");
const price_controller_1 = require("../controller/price-controller");
const calculation_controller_1 = require("../controller/calculation-controller");
exports.publicRouter = express_1.default.Router();
exports.publicRouter.post('/v1/auth/register', auth_controller_1.AuthController.register);
exports.publicRouter.post('/v1/auth/login', auth_controller_1.AuthController.login);
exports.publicRouter.get('/v1/price/:name', price_controller_1.PriceController.getAll);
exports.publicRouter.patch('/v1/price/:name/bulk', price_controller_1.PriceController.bulkUpdate);
exports.publicRouter.post('/v1/calculation', calculation_controller_1.CalculationController.create);
exports.publicRouter.get('/v1/calculation/:id', calculation_controller_1.CalculationController.get);
