"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authApi = void 0;
const express_1 = __importDefault(require("express"));
const auth_controller_1 = require("../controller/auth-controller");
const auth_middleware_1 = require("../middleware/auth-middleware");
exports.authApi = express_1.default.Router();
exports.authApi.use(auth_middleware_1.authMiddleware);
exports.authApi.get('/v1/auth/me', auth_controller_1.AuthController.me);
exports.authApi.post('/v1/auth/logout', auth_controller_1.AuthController.logout);
